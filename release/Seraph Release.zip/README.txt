SERAPH 1.0

HOW TO INSTALL:
 1. Drag «bin/wsock32.dll» and «bin/seraph.dll» into your BYOND/bin folder. This is usually «C:\Program Files (x86)\BYOND\bin».
 2. Drag the «Seraph» folder into «My Documents/BYOND». It should be next to "key.txt" and "cache".
 3. Launch BYOND! A configuration file will be auto-generated, allowing you to change your CID, keybinds, etc.

Should work for all BYOND 513 versions, and 512 too, in both native Windows and Wine/Proton.
	NOTE: if you're using Wine, disable D9VK/DXVK! It breaks BYOND!

Plugin source in «src» folder.
Plugin SDK in «sdk» folder.
